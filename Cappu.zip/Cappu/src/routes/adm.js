// src/routes/adm.js
const express = require("express");
const router = express.Router();
const { isAdmin } = require("../middleware/authe");
const { query } = require("../utils/db");

// Aplicar o middleware isAdmin para todas as rotas de /adm
router.use(isAdmin);

// Rota principal do painel administrativo (adm-painel.ejs)
router.get("/", (req, res) => {
    res.redirect("/adm/adm-painel"); 
});

router.get("/adm-painel", async (req, res) => {
    try {
        const [[totalUsuariosRows], [totalCursosRows], [totalProfessoresRows], [totalAlunosRows]] = await Promise.all([
            query("SELECT COUNT(*) as total FROM users"),
            query("SELECT COUNT(*) as total FROM cursos"),
            query("SELECT COUNT(*) as total FROM users WHERE role = 'professor'"),
            query("SELECT COUNT(*) as total FROM users WHERE role = 'aluno'")
        ]);
        
        // Mock para cursos mais vendidos, substitua por consulta real se tiver a tabela 'vendas' ou 'inscricoes'
        const cursosMaisVendidos = [
            { nome: "Lógica de Programação Essencial", vendas: 150 },
            { nome: "Design UI/UX para Iniciantes", vendas: 120 }
        ];

        // Mock para ultimos usuários e cursos
        const ultimosUsuarios = await query("SELECT name, email, DATE_FORMAT(created_at, '%d/%m/%Y') as dataCadastro FROM users ORDER BY created_at DESC LIMIT 3");
        const ultimosCursos = await query("SELECT titulo, status FROM cursos ORDER BY created_at DESC LIMIT 3");


        res.render("dashboard/adm/adm-painel", {
            user: req.user,
            title: "Painel Administrativo",
            layout: "./layouts/adm_layout",
            totalUsuarios: totalUsuariosRows ? totalUsuariosRows.total : 0,
            totalCursos: totalCursosRows ? totalCursosRows.total : 0,
            totalProfessores: totalProfessoresRows ? totalProfessoresRows.total : 0,
            totalAlunos: totalAlunosRows ? totalAlunosRows.total : 0,
            cursosMaisVendidos,
            ultimosUsuarios,
            ultimosCursos,
            messages: { success: req.flash('success'), error: req.flash('error') }
        });
    } catch (error) {
        console.error("Erro ao carregar painel administrativo:", error);
        req.flash('error', 'Erro ao carregar o painel administrativo.');
        res.redirect('/'); 
    }
});

// Rota para gerenciar usuários (adm-usuarios.ejs)
router.get("/adm-usuarios", async (req, res) => {
    try {
        const searchTerm = req.query.search || '';
        let queryStr = "SELECT id, name, email, role, DATE_FORMAT(created_at, '%d/%m/%Y') as data_cadastro, status FROM users";
        const params = [];
        if (searchTerm) {
            queryStr += " WHERE (name LIKE ? OR email LIKE ?)";
            params.push(`%${searchTerm}%`, `%${searchTerm}%`);
        }
        queryStr += " ORDER BY created_at DESC";

        const usuarios = await query(queryStr, params);
        res.render("dashboard/adm/adm-usuarios", {
            user: req.user,
            title: "Gerenciar Usuários",
            layout: "./layouts/adm_layout",
            usuarios: usuarios,
            searchTerm: searchTerm,
            messages: { success: req.flash('success'), error: req.flash('error') }
        });
    } catch (error) {
        console.error("Erro ao buscar usuários:", error);
        req.flash('error', 'Não foi possível carregar a lista de usuários.');
        res.redirect("/adm/adm-painel");
    }
});

// Rota para gerenciar cursos (adm-cursos.ejs)
router.get("/adm-cursos", async (req, res) => {
    try {
        const searchTerm = req.query.search || '';
        let queryStr = `
            SELECT c.id, c.titulo, c.categoria, c.status, u.name as professor_nome,
                   DATE_FORMAT(c.created_at, '%d/%m/%Y') as data_criacao
            FROM cursos c
            LEFT JOIN users u ON c.professor_id = u.id  
        `;
        const params = [];
        if (searchTerm) {
            queryStr += " WHERE (c.titulo LIKE ? OR u.name LIKE ? OR c.categoria LIKE ?)";
            params.push(`%${searchTerm}%`, `%${searchTerm}%`, `%${searchTerm}%`);
        }
        queryStr += " ORDER BY c.created_at DESC";

        const cursos = await query(queryStr, params);
        res.render("dashboard/adm/adm-cursos", {
            user: req.user,
            title: "Gerenciar Cursos",
            layout: "./layouts/adm_layout",
            cursos: cursos,
            searchTerm: searchTerm,
            messages: { success: req.flash('success'), error: req.flash('error') }
        });
    } catch (error) {
        console.error("Erro ao buscar cursos:", error);
        req.flash('error', 'Não foi possível carregar la lista de cursos.');
        res.redirect("/adm/adm-painel");
    }
});

// Rota para visão financeira (adm-financeiro.ejs)
router.get("/adm-financeiro", async (req, res) => {
    try {
        // Mock de dados financeiros para demonstração, idealmente viriam do banco
        const faturamentoTotal = 25850.50;
        const faturamentoMensal = 3120.70;
        const novosAlunosMes = 42;
        const cursosMaisVendidos = [
            { nome: "Curso Completo de Programação Web", vendas: 88 },
            { nome: "Marketing Digital para Empreendedores", vendas: 75 },
        ];
        const faturamentoUltimosMeses = [
            { mes: "Dez/24", total: 2800.00 }, { mes: "Jan/25", total: 3200.00 },
            { mes: "Fev/25", total: 2950.00 }, { mes: "Mar/25", total: 3500.00 },
            { mes: "Abr/25", total: 3300.00 }, { mes: "Mai/25", total: 3120.70 }
        ];

        res.render("dashboard/adm/adm-financeiro", {
            user: req.user,
            title: "Visão Financeira",
            layout: "./layouts/adm_layout",
            faturamentoTotal,
            faturamentoMensal,
            novosAlunosMes,
            cursosMaisVendidos,
            faturamentoUltimosMeses,
            messages: { success: req.flash('success'), error: req.flash('error') }
        });
    } catch (error) {
        console.error("Erro ao carregar dados financeiros:", error);
        req.flash('error', 'Erro ao carregar dados financeiros.');
        res.redirect("/adm/adm-painel");
    }
});

// Rota para tickets de suporte (adm-suporte.ejs)
router.get("/adm-suporte", async (req, res) => {
    try {
        const searchTerm = req.query.search || '';
        // Mock de dados de tickets, idealmente viriam do banco de uma tabela 'suporte_tickets'
        let tickets = [ 
            {id: 1, user_id: 2, nome_usuario: "Carlos Andrade", email_usuario: "carlos@example.com", assunto: "Problema ao acessar aula X", mensagem: "Não consigo carregar o vídeo da aula X sobre Python.", created_at: new Date(2025, 4, 29, 10, 30), data_abertura: "29/05/2025 10:30", status: "aberto"},
            {id: 2, user_id: 3, nome_usuario: "Beatriz Costa", email_usuario: "bia.costa@example.com", assunto: "Certificado não emitido", mensagem: "Concluí o curso de Design mas o certificado não aparece.", created_at: new Date(2025, 4, 28, 15, 0), data_abertura: "28/05/2025 15:00", status: "resolvido"}
        ];

        if (searchTerm) {
            tickets = tickets.filter(ticket => 
                ticket.assunto.toLowerCase().includes(searchTerm.toLowerCase()) ||
                ticket.nome_usuario.toLowerCase().includes(searchTerm.toLowerCase()) ||
                ticket.email_usuario.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }
        
        res.render("dashboard/adm/adm-suporte", {
            user: req.user,
            title: "Tickets de Suporte",
            layout: "./layouts/adm_layout",
            tickets: tickets,
            searchTerm: searchTerm,
            messages: { success: req.flash('success'), error: req.flash('error') }
        });
    } catch (error) {
        console.error("Erro ao carregar tickets de suporte:", error);
        req.flash('error', 'Erro ao carregar tickets de suporte.');
        res.redirect("/adm/adm-painel");
    }
});

// Rota para aprovar/reprovar/pendenciar cursos
router.post("/adm-cursos/status/:id", async (req, res) => {
    const cursoId = req.params.id;
    const { novoStatus } = req.body;

    if (!['aprovado', 'reprovado', 'pendente'].includes(novoStatus)) {
        req.flash("error", "Status inválido.");
        return res.redirect("/adm/adm-cursos");
    }

    try {
        await query("UPDATE cursos SET status = ? WHERE id = ?", [novoStatus, cursoId]);
        req.flash("success", `Status do curso ${cursoId} atualizado para ${novoStatus}.`);
    } catch (error) {
        console.error("Erro ao atualizar status do curso:", error);
        req.flash("error", "Erro ao atualizar status do curso.");
    }
    res.redirect("/adm/adm-cursos");
});

// Rota para ativar/banir usuários
router.post("/adm-usuarios/status/:id", async (req, res) => {
    const usuarioId = req.params.id;
    const { novoStatus } = req.body;

    if (!['active', 'banned', 'pending_approval'].includes(novoStatus)) {
        req.flash("error", "Status de usuário inválido.");
        return res.redirect("/adm/adm-usuarios");
    }

    if (parseInt(usuarioId) === parseInt(req.user.id) && novoStatus === 'banned') {
        req.flash("error", "Você não pode banir a si mesmo.");
        return res.redirect("/adm/adm-usuarios");
    }

    try {
        await query("UPDATE users SET status = ? WHERE id = ?", [novoStatus, usuarioId]);
        req.flash("success", `Status do usuário ${usuarioId} atualizado para ${novoStatus}.`);
    } catch (error) {
        console.error("Erro ao atualizar status do usuário:", error);
        req.flash("error", "Erro ao atualizar status do usuário.");
    }
    res.redirect("/adm/adm-usuarios");
});

// Rota para ver detalhes de um ticket de suporte (adm-suporte-detalhe.ejs)
router.get("/adm-suporte/ticket/:id", async (req, res) => {
    const ticketId = req.params.id;
    try {
        // Mock de dados, substitua por consulta real
        const mockTickets = [
             {id: 1, user_id: 2, nome_usuario: "Carlos Andrade", email_usuario: "carlos@example.com", assunto: "Problema ao acessar aula X", mensagem_original: "Não consigo carregar o vídeo da aula X sobre Python.", created_at: new Date(2025, 4, 29, 10, 30), data_formatada: "29/05/2025 10:30:00", status: "aberto", respostas: []},
             {id: 2, user_id: 3, nome_usuario: "Beatriz Costa", email_usuario: "bia.costa@example.com", assunto: "Certificado não emitido", mensagem_original: "Concluí o curso de Design mas o certificado não aparece.", created_at: new Date(2025, 4, 28, 15, 0), data_formatada: "28/05/2025 15:00:00", status: "resolvido", respostas: [{user_id: req.user.id, nome_admin: "Admin Suporte", mensagem: "Olá Beatriz, verificamos e seu certificado foi reenviado.", data_resposta: "28/05/2025 16:00"}]}
        ];
        const ticket = mockTickets.find(t => t.id == ticketId);

        if (!ticket) {
            req.flash("error", "Ticket não encontrado.");
            return res.redirect("/adm/adm-suporte");
        }

        res.render("dashboard/adm/adm-suporte-detalhe", { 
            user: req.user,
            title: `Detalhe Ticket #${ticket.id}`,
            layout: "./layouts/adm_layout",
            ticket: ticket,
            messages: { success: req.flash('success'), error: req.flash('error') }
        });
    } catch (error) {
        console.error("Erro ao buscar detalhes do ticket:", error);
        req.flash("error", "Erro ao buscar detalhes do ticket.");
        res.redirect("/adm/adm-suporte");
    }
});

// Rota para responder/atualizar um ticket de suporte
router.post("/adm-suporte/ticket/:id/responder", async (req, res) => {
    const ticketId = req.params.id;
    const { resposta, novoStatusTicket } = req.body;

    if (!resposta || !novoStatusTicket) {
        req.flash("error", "Resposta e novo status são obrigatórios.");
        return res.redirect(`/adm/adm-suporte/ticket/${ticketId}`);
    }
    if (!['aberto', 'em_andamento', 'resolvido', 'fechado'].includes(novoStatusTicket)) {
        req.flash("error", "Status de ticket inválido.");
        return res.redirect(`/adm/adm-suporte/ticket/${ticketId}`);
    }

    try {
        // Lógica para salvar a resposta e atualizar o status do ticket no banco de dados
        // Exemplo: await query("INSERT INTO suporte_respostas (ticket_id, admin_id, texto_resposta) VALUES (?, ?, ?)", [ticketId, req.user.id, resposta]);
        // Exemplo: await query("UPDATE suporte_tickets SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", [novoStatusTicket, ticketId]);
        
        console.log(`Ticket ${ticketId} respondido pelo admin ${req.user.id} com status ${novoStatusTicket}: ${resposta}`);
        req.flash("success", "Resposta enviada e status do ticket atualizado.");
    } catch (error) {
        console.error("Erro ao responder ticket:", error);
        req.flash("error", "Erro ao responder ticket.");
    }
    res.redirect(`/adm/adm-suporte/ticket/${ticketId}`);
});

// Rota para adicionar/editar usuários (GET para formulário)
router.get("/adm-usuarios/editar/:id?", async (req, res) => {
    const usuarioId = req.params.id;
    let usuarioParaEditar = null;
    if (usuarioId) {
        const [userFound] = await query("SELECT * FROM users WHERE id = ?", [usuarioId]);
        if (!userFound) {
            req.flash('error', 'Usuário não encontrado.');
            return res.redirect('/adm/adm-usuarios');
        }
        usuarioParaEditar = userFound;
    }
    res.render("dashboard/adm/adm-usuario-form", {
        user: req.user,
        title: usuarioId ? "Editar Usuário" : "Adicionar Usuário",
        layout: "./layouts/adm_layout",
        usuarioEdicao: usuarioParaEditar, // Passa o usuário para o formulário (null se for novo)
        messages: { success: req.flash('success'), error: req.flash('error') }
    });
});

// Rota para adicionar/editar usuários (POST do formulário)
const bcrypt = require("bcryptjs"); // Certifique-se de ter bcryptjs instalado

router.post("/adm-usuarios/salvar/:id?", async (req, res) => {
    const usuarioId = req.params.id;
    const { name, email, role, status, password } = req.body;

    if (!name || !email || !role || !status) {
        req.flash('error', 'Todos os campos, exceto senha, são obrigatórios.');
        return res.redirect(usuarioId ? `/adm/adm-usuarios/editar/${usuarioId}` : '/adm/adm-usuarios/editar');
    }

    try {
        if (usuarioId) { // Editando usuário
            let updateQuery = "UPDATE users SET name = ?, email = ?, role = ?, status = ?";
            const params = [name, email, role, status];
            if (password) { // Se uma nova senha foi fornecida
                const hashedPassword = await bcrypt.hash(password, 12);
                updateQuery += ", password = ?";
                params.push(hashedPassword);
            }
            updateQuery += " WHERE id = ?";
            params.push(usuarioId);
            await query(updateQuery, params);
            req.flash('success', 'Usuário atualizado com sucesso!');
        } else { // Adicionando novo usuário
            if (!password) {
                req.flash('error', 'Senha é obrigatória para novos usuários.');
                return res.redirect('/adm/adm-usuarios/editar');
            }
            const existingUser = await query('SELECT * FROM users WHERE email = ?', [email]);
            if (existingUser.length > 0) {
                req.flash("error", "Email já cadastrado.");
                return res.redirect('/adm/adm-usuarios/editar');
            }
            const hashedPassword = await bcrypt.hash(password, 12);
            await query('INSERT INTO users (name, email, password, role, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())', 
                [name, email, hashedPassword, role, status]);
            req.flash('success', 'Usuário adicionado com sucesso!');
        }
        res.redirect('/adm/adm-usuarios');
    } catch (error) {
        console.error("Erro ao salvar usuário:", error);
        req.flash('error', 'Erro ao salvar usuário.');
        res.redirect(usuarioId ? `/adm/adm-usuarios/editar/${usuarioId}` : '/adm/adm-usuarios/editar');
    }
});


module.exports = router;