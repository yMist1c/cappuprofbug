class Resumos {
    constructor({
        COD_RESUMO,
        ID_USUARIO,
        DATA_RESUMO,
        TEXTO_RESUMO
    }) {
        this.COD_RESUMO = COD_RESUMO;
        this.ID_USUARIO = ID_USUARIO;
        this.DATA_RESUMO = DATA_RESUMO;
        this.TEXTO_RESUMO = TEXTO_RESUMO;
    }
}

module.exports = Resumos;
