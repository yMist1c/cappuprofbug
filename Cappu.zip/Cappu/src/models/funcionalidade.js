class Funcionalidade {
    constructor({
        COD_FUNCIONALIDADE,
        COD_ESTILO,
        NOME_FUNCIONALIDADE,
        DESC_FUNCIONALIDADE
    }) {
        this.COD_FUNCIONALIDADE = COD_FUNCIONALIDADE;
        this.COD_ESTILO = COD_ESTILO;
        this.NOME_FUNCIONALIDADE = NOME_FUNCIONALIDADE;
        this.DESC_FUNCIONALIDADE = DESC_FUNCIONALIDADE;
    }
}

module.exports = Funcionalidade;
