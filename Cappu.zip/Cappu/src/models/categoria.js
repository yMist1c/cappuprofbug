class Categoria {
    constructor({
        ID_CATEGORIA,
        DESCRICAO,
        NOME
    }) {
        this.ID_CATEGORIA = ID_CATEGORIA;
        this.DESCRICAO = DESCRICAO;
        this.NOME = NOME;
    }
}

module.exports = Categoria;
