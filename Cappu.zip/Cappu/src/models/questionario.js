class Questionario {
    constructor({
        ID_QUEST,
        TITULO,
        DATA_HORA_CRIACAO
    }) {
        this.ID_QUEST = ID_QUEST;
        this.TITULO = TITULO;
        this.DATA_HORA_CRIACAO = DATA_HORA_CRIACAO;
    }
}

module.exports = Questionario;
