class QuestAnalise {
    constructor({
        COD_QUESTAO,
        COD_ANALISE,
        ID_USUARIO,
        RESPOSTA
    }) {
        this.COD_QUESTAO = COD_QUESTAO;
        this.COD_ANALISE = COD_ANALISE;
        this.ID_USUARIO = ID_USUARIO;
        this.RESPOSTA = RESPOSTA;
    }
}

module.exports = QuestAnalise;
