class EstiloAprendizagem {
    constructor({
        COD_ESTILO,
        NOME_ESTILO,
        DESC_ESTILO,
        TIPO_METODO
    }) {
        this.COD_ESTILO = COD_ESTILO;
        this.NOME_ESTILO = NOME_ESTILO;
        this.DESC_ESTILO = DESC_ESTILO;
        this.TIPO_METODO = TIPO_METODO;
    }
}

module.exports = EstiloAprendizagem;
