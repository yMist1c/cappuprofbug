// src/middleware/authe.js
module.exports = {
  isLoggedIn: (req, res, next) => {
    if (req.isAuthenticated()) return next();
    req.flash('error', 'Faça login primeiro');
    res.redirect('/authe/cl-login');
  },

  isNotLoggedIn: (req, res, next) => {
    if (!req.isAuthenticated()) return next();
    // Se logado, redireciona baseado no papel ou para uma página padrão
    const redirectTo = req.user && req.user.role ? (req.user.role === 'admin' ? '/adm/adm-painel' : (req.user.role === 'professor' ? '/professor/p-professor' : '/aluno/a-perfil')) : '/';
    res.redirect(redirectTo);
  },

  isAuthenticated: (req, res, next) => {
    if (req.isAuthenticated()) {
      return next();
    }
    req.flash("error", "Você precisa estar logado para acessar esta página");
    res.redirect("/authe/cl-login"); 
  },

  isProfessor: (req, res, next) => {
    if (req.isAuthenticated() && req.user && req.user.role === "professor") {
      return next();
    }
    req.flash('error', 'Acesso restrito a professores');
    if (req.isAuthenticated()) {
        res.redirect(req.user.role === 'admin' ? '/adm/adm-painel' : '/aluno/a-perfil');
    } else {
        res.redirect('/authe/cl-login');
    }
  },

  isAluno: (req, res, next) => {
    if (req.isAuthenticated() && req.user && req.user.role === "aluno") {
      return next();
    }
    req.flash('error', 'Acesso restrito a alunos');
    if (req.isAuthenticated()) {
        res.redirect(req.user.role === 'admin' ? '/adm/adm-painel' : '/professor/p-professor');
    } else {
        res.redirect('/authe/cl-login');
    }
  },

  isAdmin: (req, res, next) => {
    if (req.isAuthenticated() && req.user && req.user.role === "admin") {
      return next();
    }
    req.flash('error', 'Acesso restrito a administradores.');
    if (req.isAuthenticated()) {
      // Se está logado mas não é admin, redireciona para o painel do seu papel ou home
      switch (req.user.role) {
        case 'aluno':
          res.redirect('/aluno/a-perfil');
          break;
        case 'professor':
          res.redirect('/professor/p-professor');
          break;
        default:
          res.redirect('/');
      }
    } else {
      // Se não está logado, redireciona para o login
      res.redirect('/authe/cl-login');
    }
  }
};